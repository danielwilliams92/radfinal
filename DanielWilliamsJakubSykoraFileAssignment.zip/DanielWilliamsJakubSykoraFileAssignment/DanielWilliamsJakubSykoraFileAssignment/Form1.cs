﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanielWilliamsJakubSykoraFileAssignment
{
    public partial class Form1 : Form
    {
       
        private StreamWriter employeeStreamWriter;

        ArrayList list = new ArrayList();

        

    public Form1()
        {
            
            InitializeComponent();
        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            saveFileDialog1.FileName = "Employees.txt";
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Title = "Save the employee";
            saveFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";
            DialogResult response = saveFileDialog1.ShowDialog();

            if(response == DialogResult.Cancel)
            {
                this.Close();
            }
            */
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            saveFileDialog1.FileName = "Employees.txt";
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Title = "Save the employee";
            saveFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            DialogResult response = saveFileDialog1.ShowDialog();

            

            if (response != DialogResult.Cancel)
            {
                try
                {
                    employeeStreamWriter = new StreamWriter(saveFileDialog1.FileName);
                    
                    
                    String value = txtEmployeesName.Text + "," + txtEmployeesNumber.Text + "," + txtEmployeesHoursWorked.Text;
                    list.Add(value);
                    

                    
                    foreach(string i in list)
                    {
                        employeeStreamWriter.WriteLine(i);
                    }
                    
                    

                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "File Creation Errorr", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                finally
                {
                    if (employeeStreamWriter != null)
                    {
                        employeeStreamWriter.Close();
                    }
                }

            }

            txtEmployeesName.Text = "";
            txtEmployeesNumber.Text = "";
            txtEmployeesHoursWorked.Text = "";
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            
            

            Form2 frm = new Form2();
            frm.Show();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void txtEmployeesName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
