﻿namespace DanielWilliamsJakubSykoraFileAssignment
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOutWeeklyPay = new System.Windows.Forms.TextBox();
            this.txtOutEmployeesHoursWorked = new System.Windows.Forms.TextBox();
            this.txtOutEmployeesNumber = new System.Windows.Forms.TextBox();
            this.txtOutEmployeesName = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnNext = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(110, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employees Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employees name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Employees Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Hours Worked";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtOutWeeklyPay);
            this.groupBox1.Controls.Add(this.txtOutEmployeesHoursWorked);
            this.groupBox1.Controls.Add(this.txtOutEmployeesNumber);
            this.groupBox1.Controls.Add(this.txtOutEmployeesName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(75, 171);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 196);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Weekly Pay";
            // 
            // txtOutWeeklyPay
            // 
            this.txtOutWeeklyPay.Location = new System.Drawing.Point(137, 135);
            this.txtOutWeeklyPay.Name = "txtOutWeeklyPay";
            this.txtOutWeeklyPay.Size = new System.Drawing.Size(100, 20);
            this.txtOutWeeklyPay.TabIndex = 7;
            // 
            // txtOutEmployeesHoursWorked
            // 
            this.txtOutEmployeesHoursWorked.Location = new System.Drawing.Point(137, 97);
            this.txtOutEmployeesHoursWorked.Name = "txtOutEmployeesHoursWorked";
            this.txtOutEmployeesHoursWorked.Size = new System.Drawing.Size(100, 20);
            this.txtOutEmployeesHoursWorked.TabIndex = 6;
            // 
            // txtOutEmployeesNumber
            // 
            this.txtOutEmployeesNumber.Location = new System.Drawing.Point(137, 71);
            this.txtOutEmployeesNumber.Name = "txtOutEmployeesNumber";
            this.txtOutEmployeesNumber.Size = new System.Drawing.Size(100, 20);
            this.txtOutEmployeesNumber.TabIndex = 5;
            // 
            // txtOutEmployeesName
            // 
            this.txtOutEmployeesName.Location = new System.Drawing.Point(137, 30);
            this.txtOutEmployeesName.Name = "txtOutEmployeesName";
            this.txtOutEmployeesName.Size = new System.Drawing.Size(100, 20);
            this.txtOutEmployeesName.TabIndex = 4;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(104, 397);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 5;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 470);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtOutEmployeesHoursWorked;
        private System.Windows.Forms.TextBox txtOutEmployeesNumber;
        private System.Windows.Forms.TextBox txtOutEmployeesName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOutWeeklyPay;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnNext;
    }
}