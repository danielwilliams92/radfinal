﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanielWilliamsJakubSykoraFileAssignment
{
    public partial class Form2 : Form
    {

        ArrayList list = new ArrayList();
        private FileStream fs;
        String line;
        int count = 0;

        private StreamReader employeeStreamReader;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.FileName = "Employees.txt";
            openFileDialog1.Title = "select file";
            openFileDialog1.Filter = "Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            DialogResult response = openFileDialog1.ShowDialog();
            employeeStreamReader = new StreamReader(openFileDialog1.FileName);
           
        }

        private void button1_Click(object sender, EventArgs e)
        {                     
            try
                {                                                      
                    String value = employeeStreamReader.ReadLine();

                    String name = value.Split(',')[0];
                    String number = value.Split(',')[1];
                    String hours = value.Split(',')[2];
                    double totalPay;

                    txtOutEmployeesName.Text = name;
                    txtOutEmployeesNumber.Text = number;
                    txtOutEmployeesHoursWorked.Text = hours;

                    double num = Int32.Parse(hours);
                    totalPay = num * 10.25;
                    txtOutWeeklyPay.Text = totalPay.ToString();
       
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "File Creation Errorr", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                finally
                {
                    if (employeeStreamReader == null)
                    {
                        employeeStreamReader.Close();
                    }
                }
        }
    }
}
